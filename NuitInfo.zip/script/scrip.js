function themeVert() {
  document.documentElement.style.setProperty('--vertClassique', '#BDDDC9')
  document.documentElement.style.setProperty('--vertHeader', '#DDEEE2')
  document.documentElement.style.setProperty('--bleue', '#6E93D6')
}

function themeBlue() {
  document.documentElement.style.setProperty('--vertClassique', '#95B6E4')
  document.documentElement.style.setProperty('--vertHeader', '#E5F1FA')
  document.documentElement.style.setProperty('--bleue', '#BDDDC9')
}
